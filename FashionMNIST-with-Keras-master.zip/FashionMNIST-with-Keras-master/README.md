# FashionMNIST-with-Keras
Pt1 - prepare F-MNIST data
